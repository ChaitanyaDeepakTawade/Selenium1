package com.StepDefinations;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentReporter;

public class Helper_Report {

	static ExtentTest test;
	static ExtentReports report;
}
